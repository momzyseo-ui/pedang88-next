import Link from "next/link";
import JsonLd from "@/components/JsonLd";
import PageShell from "@/components/PageShell";
import { breadcrumbNode, faqPageNode, graph } from "@/lib/schema";
import { buildMetadata } from "@/lib/seo";
import { site } from "@/lib/site";

const path = "/faq";
const title = "FAQ: Pertanyaan Seputar Top Up Game";
const description =
  "Jawaban atas pertanyaan umum tentang PEDANG TOP UP: cara top up, ID game, keamanan akun, refund, dan hubungan dengan publisher game.";
const crumbs = [
  { name: "Beranda", path: "/" },
  { name: "FAQ", path },
];

/** Sumber tunggal: dipakai untuk tampilan DAN schema, jadi keduanya selalu identik. */
const faqs = [
  {
    question: "Apa itu PEDANG TOP UP?",
    answer: `${site.name} adalah brand yang menyajikan informasi dan jalur pemesanan top up game ${site.games.join(", ")}. Pesanan dibuat dan dibayar di toko kami, bukan di situs ini.`,
  },
  {
    question: "Apakah transaksi dilakukan di situs ini?",
    answer:
      "Tidak. Situs ini tidak memproses pesanan atau pembayaran. Tombol Masuk, Daftar, dan Top up sekarang membuka toko tempat transaksi dilakukan.",
  },
  {
    question: "Game apa saja yang dilayani?",
    answer: `Saat ini ${site.games.join(", ")}. Ketersediaan nominal mengikuti yang tampil di toko.`,
  },
  {
    question: "Data apa yang saya butuhkan untuk top up?",
    answer:
      "ID game kamu, yaitu User ID dan Zone ID bila game memintanya, serta nominal yang dipilih. Kamu tidak perlu memberikan password akun game.",
  },
  {
    question: "Apakah saya perlu memberikan password atau kode OTP?",
    answer:
      "Tidak. Top up tidak membutuhkan password maupun kode OTP. Jangan membagikannya kepada siapa pun, termasuk yang mengaku sebagai admin.",
  },
  {
    question: "Bagaimana jika saya salah memasukkan ID game?",
    answer:
      "Periksa ID sebelum membayar. ID yang salah bisa membuat pesanan gagal atau masuk ke akun lain. Jika sudah terlanjur, segera hubungi toko dengan nomor pesanan dan bukti pembayaran. Penanganannya mengikuti kebijakan toko.",
  },
  {
    question: "Bagaimana kebijakan pengembalian dana?",
    answer:
      "Pengembalian dana mengikuti kebijakan toko tempat transaksi dilakukan. Ringkasannya ada di halaman Syarat dan Ketentuan.",
  },
  {
    question: "Apakah PEDANG TOP UP berafiliasi dengan publisher game?",
    answer:
      "Tidak. Kami tidak berafiliasi dengan atau didukung oleh publisher game mana pun. Semua nama dan merek dagang game adalah milik pemiliknya masing-masing.",
  },
  {
    question: "Bagaimana cara menghubungi kami?",
    answer: "Gunakan kanal yang tercantum di halaman Kontak.",
  },
];

export const metadata = buildMetadata({ title, description, path });

export default function FaqPage() {
  return (
    <>
      <JsonLd
        data={graph([faqPageNode(path, { name: title, description, faqs }), breadcrumbNode(path, crumbs)])}
      />
      <PageShell
        title="FAQ"
        intro="Jawaban singkat untuk pertanyaan yang paling sering muncul."
        crumbs={crumbs}
      >
        {faqs.map((faq) => (
          <section key={faq.question}>
            <h2>{faq.question}</h2>
            <p>{faq.answer}</p>
          </section>
        ))}
        <p>
          Belum menemukan jawabannya? Lihat <Link href="/cara-order">cara order</Link> atau{" "}
          <Link href="/kontak">hubungi kami</Link>.
        </p>
      </PageShell>
    </>
  );
}
