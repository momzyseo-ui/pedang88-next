import Link from "next/link";
import CodeRain from "@/components/CodeRain";
import HeroTerminal from "@/components/HeroTerminal";
import JsonLd from "@/components/JsonLd";
import { graph, serviceNode, webPageNode } from "@/lib/schema";
import { buildMetadata } from "@/lib/seo";
import { site, moneysiteLink } from "@/lib/site";

export const metadata = buildMetadata({
  title: site.homeTitle,
  absoluteTitle: true,
  description: site.description,
  path: "/",
});

const steps = [
  {
    title: "Pilih game dan nominal",
    text: "Buka toko kami, lalu pilih game dan nominal yang kamu butuhkan.",
  },
  {
    title: "Isi ID game dengan teliti",
    text: "Periksa kembali User ID dan Zone ID sebelum lanjut. ID yang salah bisa membuat pesanan gagal.",
  },
  {
    title: "Bayar dan tunggu konfirmasi",
    text: "Selesaikan pembayaran di toko dan pantau status pesananmu di sana.",
  },
];

const slug = (value: string) => value.toLowerCase().replace(/\s+/g, "_");

export default function Home() {
  return (
    <>
      <JsonLd
        data={graph([
          webPageNode("/", { name: site.homeTitle, description: site.description }),
          serviceNode(),
        ])}
      />

      <section className="blade relative isolate overflow-hidden bg-panel">
        <CodeRain className="code-mask absolute inset-0 -z-10 h-full w-full opacity-25" />

        <div className="mx-auto grid max-w-6xl gap-12 px-5 pb-28 pt-16 md:grid-cols-[1.1fr_0.9fr] md:items-center md:pb-36 md:pt-24">
          <div>
            <p className="font-mono text-sm text-accent">// top up game</p>
            <h1 className="font-display mt-3 text-5xl font-bold leading-[1.02] md:text-7xl">PEDANG TOP UP</h1>
            <p className="mt-6 max-w-xl text-lg text-steel">
              Top up Mobile Legends, PUBG Mobile, Fortnite, dan Minecraft dengan alur yang jelas dari awal sampai
              bayar.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <a
                href={moneysiteLink("base", "hero_topup")}
                rel="noopener"
                className="cut-corner bg-accent px-7 py-3.5 font-bold text-ink hover:brightness-110"
              >
                Top up sekarang
              </a>
              <Link
                href="/cara-order"
                className="border border-line px-7 py-3.5 font-semibold transition-colors hover:border-accent"
              >
                Lihat cara order
              </Link>
            </div>
          </div>

          <HeroTerminal />
        </div>
      </section>

      <section aria-labelledby="games-heading" className="mx-auto max-w-6xl px-5 py-20">
        <p className="font-mono text-sm text-accent">// game</p>
        <h2 id="games-heading" className="font-display mt-2 text-3xl font-bold">
          Game yang dilayani
        </h2>
        <ul className="mt-8 grid gap-4 sm:grid-cols-2">
          {site.games.map((game) => (
            <li
              key={game}
              className="flex items-center justify-between gap-4 border border-line bg-panel p-5 transition-colors hover:border-accent"
            >
              <span className="font-display text-xl font-semibold">{game}</span>
              <a
                href={moneysiteLink("base", `game_${slug(game)}`)}
                rel="noopener"
                className="shrink-0 text-sm font-semibold text-accent hover:underline"
              >
                Top up {game}
              </a>
            </li>
          ))}
        </ul>
      </section>

      <section aria-labelledby="steps-heading" className="mx-auto max-w-6xl px-5 pb-20">
        <p className="font-mono text-sm text-accent">// langkah</p>
        <h2 id="steps-heading" className="font-display mt-2 text-3xl font-bold">
          Cara kerjanya
        </h2>
        <ol className="mt-8 grid gap-6 md:grid-cols-3">
          {steps.map((step, index) => (
            <li key={step.title} className="border-t border-line pt-5">
              <span className="font-mono text-3xl font-bold text-accent">{String(index + 1).padStart(2, "0")}</span>
              <h3 className="font-display mt-3 text-xl font-semibold">{step.title}</h3>
              <p className="mt-2 text-[15px] text-steel">{step.text}</p>
            </li>
          ))}
        </ol>
      </section>

      <section aria-labelledby="safety-heading" className="mx-auto max-w-6xl px-5">
        <div className="border border-line bg-panel p-7 md:p-10">
          <h2 id="safety-heading" className="font-display text-2xl font-bold">
            Jaga akun gamemu
          </h2>
          <p className="mt-3 max-w-2xl text-steel">
            Jangan pernah membagikan password atau kode OTP kepada siapa pun, termasuk yang mengaku sebagai admin.
            Top up hanya membutuhkan ID game, bukan kata sandi.
          </p>
        </div>
      </section>
    </>
  );
}
