import Link from "next/link";
import JsonLd from "@/components/JsonLd";
import PageShell from "@/components/PageShell";
import { breadcrumbNode, graph, webPageNode } from "@/lib/schema";
import { buildMetadata } from "@/lib/seo";
import { moneysiteLink } from "@/lib/site";

const path = "/cara-order";
const title = "Cara Order Top Up Game";
const description =
  "Panduan order di PEDANG TOP UP: pilih game dan nominal, isi ID game dengan teliti, lalu bayar di toko kami. Langkah jelas dan tips agar pesanan tidak gagal.";
const crumbs = [
  { name: "Beranda", path: "/" },
  { name: "Cara order", path },
];

export const metadata = buildMetadata({ title, description, path });

export default function CaraOrderPage() {
  return (
    <>
      <JsonLd
        data={graph([webPageNode(path, { name: title, description, breadcrumb: true }), breadcrumbNode(path, crumbs)])}
      />
      <PageShell
        title={title}
        intro="Situs ini mengantarmu ke toko tempat pesanan dibuat. Ikuti langkah berikut supaya prosesnya lancar."
        crumbs={crumbs}
      >
        <h2>Langkah order</h2>
        <ol>
          <li>
            <strong>Buka toko.</strong> Klik tombol Top up sekarang, atau tombol Masuk dan Daftar di bagian atas
            halaman. Kamu akan diarahkan ke toko tempat transaksi dilakukan.
          </li>
          <li>
            <strong>Pilih game dan nominal.</strong> Pilih Mobile Legends, PUBG Mobile, Fortnite, atau Minecraft,
            lalu pilih nominal yang kamu butuhkan.
          </li>
          <li>
            <strong>Isi ID game dengan teliti.</strong> Masukkan User ID, dan Zone ID bila game memintanya. Periksa
            sekali lagi sebelum melanjutkan.
          </li>
          <li>
            <strong>Pilih metode pembayaran dan bayar.</strong> Metode yang tersedia mengikuti pilihan di toko.
          </li>
          <li>
            <strong>Pantau status pesanan.</strong> Status pesanan dapat dilihat di toko. Simpan bukti pembayaran
            sampai pesanan selesai.
          </li>
        </ol>

        <h2>Tips agar pesanan tidak gagal</h2>
        <ul>
          <li>Pastikan User ID dan Zone ID benar. ID yang salah bisa membuat pesanan gagal atau masuk ke akun lain.</li>
          <li>Periksa kembali game dan nominal sebelum membayar.</li>
          <li>Top up hanya membutuhkan ID game. Jangan pernah membagikan password atau kode OTP kepada siapa pun.</li>
          <li>Simpan nomor pesanan dan bukti pembayaran untuk jaga-jaga bila perlu bantuan.</li>
        </ul>

        <h2>Butuh bantuan?</h2>
        <p>
          Lihat <Link href="/faq">pertanyaan yang sering diajukan</Link> atau hubungi kami lewat halaman{" "}
          <Link href="/kontak">Kontak</Link>. Ketentuan pengembalian dana ada di{" "}
          <Link href="/syarat-ketentuan#refund">Syarat dan Ketentuan</Link>.
        </p>
        <p>
          <a
            href={moneysiteLink("base", "cara_order_cta")}
            rel="noopener"
            className="cut-corner inline-block bg-accent px-7 py-3.5 font-bold text-ink no-underline hover:brightness-110"
          >
            Top up sekarang
          </a>
        </p>
      </PageShell>
    </>
  );
}
