import Link from "next/link";
import JsonLd from "@/components/JsonLd";
import PageShell from "@/components/PageShell";
import { breadcrumbNode, graph, webPageNode } from "@/lib/schema";
import { buildMetadata } from "@/lib/seo";
import { site } from "@/lib/site";

const path = "/kebijakan-privasi";
const title = "Kebijakan Privasi";
const description =
  "Kebijakan privasi PEDANG TOP UP: data apa yang kami kumpulkan, penggunaan cookie, tautan ke toko, dan cara menghubungi kami terkait privasi.";
const crumbs = [
  { name: "Beranda", path: "/" },
  { name: "Kebijakan privasi", path },
];
const updated = "24 Oktober 2026";

export const metadata = buildMetadata({ title, description, path });

export default function KebijakanPrivasiPage() {
  return (
    <>
      <JsonLd
        data={graph([webPageNode(path, { name: title, description, breadcrumb: true }), breadcrumbNode(path, crumbs)])}
      />
      <PageShell title={title} intro={`Terakhir diperbarui: ${updated}`} crumbs={crumbs}>
        <p>
          Halaman ini menjelaskan bagaimana {site.name} memperlakukan data saat kamu mengunjungi situs ini.
        </p>

        <h2>Data yang kami kumpulkan</h2>
        <p>
          Situs ini tidak menyediakan akun, formulir, atau pembayaran, sehingga kami tidak meminta data pribadi
          melalui situs ini. Seperti umumnya situs web, penyedia hosting dapat mencatat data teknis standar, misalnya
          alamat IP, jenis peramban, dan halaman yang diakses, untuk keperluan keamanan dan operasional.
        </p>

        <h2>Cookie dan analitik</h2>
        <p>
          Saat ini situs ini tidak menyetel cookie pelacakan sendiri. Jika di kemudian hari kami menambahkan alat
          analitik, halaman ini akan diperbarui dan tanggal pembaruan di atas akan berubah.
        </p>

        <h2>Tautan ke toko</h2>
        <p>
          Tombol Masuk, Daftar, dan Top up sekarang membuka toko tempat transaksi dilakukan. Tautan itu menyertakan
          parameter UTM (utm_source, utm_medium, utm_campaign) yang hanya berisi informasi penempatan tombol, bukan
          data pribadimu. Setelah kamu berada di toko, kebijakan privasi toko berlaku untuk data yang kamu berikan
          di sana.
        </p>

        <h2>Keamanan akun game</h2>
        <p>
          Kami tidak pernah meminta password atau kode OTP. Jangan membagikannya kepada siapa pun.
        </p>

        <h2>Perubahan kebijakan</h2>
        <p>
          Kami dapat memperbarui kebijakan ini sewaktu-waktu. Versi terbaru selalu ada di halaman ini beserta tanggal
          pembaruannya.
        </p>

        <h2>Kontak</h2>
        <p>
          Pertanyaan tentang privasi dapat disampaikan lewat halaman <Link href="/kontak">Kontak</Link>.
        </p>
      </PageShell>
    </>
  );
}
