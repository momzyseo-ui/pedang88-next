import JsonLd from "@/components/JsonLd";
import PageShell from "@/components/PageShell";
import { breadcrumbNode, graph, webPageNode } from "@/lib/schema";
import { buildMetadata } from "@/lib/seo";
import { site } from "@/lib/site";

const path = "/kontak";
const title = "Kontak";
const description =
  "Hubungi PEDANG TOP UP untuk pertanyaan seputar situs atau pesanan. Lihat kanal kontak dan informasi yang perlu disiapkan agar bantuan lebih cepat.";
const crumbs = [
  { name: "Beranda", path: "/" },
  { name: "Kontak", path },
];

export const metadata = buildMetadata({ title, description, path });

type Channel = { label: string; value: string; href: string };

const channels = [
  site.whatsapp && { label: "WhatsApp", value: `+${site.whatsapp}`, href: `https://wa.me/${site.whatsapp}` },
  site.email && { label: "Email", value: site.email, href: `mailto:${site.email}` },
  site.telephone && {
    label: "Telepon",
    value: site.telephone,
    href: `tel:${site.telephone.replace(/[^+\d]/g, "")}`,
  },
].filter((channel): channel is Channel => Boolean(channel));

export default function KontakPage() {
  return (
    <>
      <JsonLd
        data={graph([
          webPageNode(path, { name: title, description, type: "ContactPage", breadcrumb: true }),
          breadcrumbNode(path, crumbs),
        ])}
      />
      <PageShell
        title={title}
        intro="Hubungi kami untuk pertanyaan seputar situs ini atau bantuan terkait pesanan."
        crumbs={crumbs}
      >
        <h2>Kanal kontak</h2>
        {channels.length > 0 ? (
          <ul>
            {channels.map((channel) => (
              <li key={channel.label}>
                <strong>{channel.label}:</strong>{" "}
                <a href={channel.href} rel="noopener">
                  {channel.value}
                </a>
              </li>
            ))}
          </ul>
        ) : (
          <p>Kanal kontak sedang disiapkan.</p>
        )}

        <h2>Agar bantuan lebih cepat</h2>
        <p>Sertakan informasi berikut saat menghubungi kami:</p>
        <ul>
          <li>Nomor pesanan dan nama game.</li>
          <li>Bukti pembayaran (tangkapan layar).</li>
          <li>Penjelasan singkat kendala yang kamu alami.</li>
        </ul>
        <p>
          Kami tidak pernah meminta password atau kode OTP akun game. Jangan kirimkan data itu kepada siapa pun.
        </p>

        <h2>Soal transaksi</h2>
        <p>
          Pesanan dan pembayaran diproses di toko. Untuk status pesanan, gunakan halaman pesanan di toko tempat kamu
          bertransaksi.
        </p>
      </PageShell>
    </>
  );
}
