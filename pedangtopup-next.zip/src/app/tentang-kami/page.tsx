import Link from "next/link";
import JsonLd from "@/components/JsonLd";
import PageShell from "@/components/PageShell";
import { breadcrumbNode, graph, webPageNode } from "@/lib/schema";
import { buildMetadata } from "@/lib/seo";
import { site } from "@/lib/site";

const path = "/tentang-kami";
const title = "Tentang Kami";
const description =
  "Kenali PEDANG TOP UP: brand informasi dan jalur pemesanan top up Mobile Legends, PUBG Mobile, Fortnite, dan Minecraft, serta cara kami bekerja.";
const crumbs = [
  { name: "Beranda", path: "/" },
  { name: "Tentang kami", path },
];

export const metadata = buildMetadata({ title, description, path });

export default function TentangKamiPage() {
  return (
    <>
      <JsonLd
        data={graph([
          webPageNode(path, { name: title, description, type: "AboutPage", breadcrumb: true }),
          breadcrumbNode(path, crumbs),
        ])}
      />
      <PageShell
        title={title}
        intro={`${site.name} membantu pemain menemukan jalur top up game yang jelas dan mudah diikuti.`}
        crumbs={crumbs}
      >
        <h2>Siapa kami</h2>
        <p>
          {site.name} adalah brand yang menyajikan informasi dan jalur pemesanan top up untuk{" "}
          {site.games.join(", ")}.
          {site.legalName ? ` Situs ini dikelola oleh ${site.legalName}.` : ""}
        </p>

        <h2>Apa yang kami lakukan</h2>
        <ul>
          <li>Menjelaskan alur order dengan bahasa yang sederhana.</li>
          <li>Memberi tips keamanan akun game dan cara menghindari kesalahan ID.</li>
          <li>Mengarahkanmu ke toko tempat pesanan dibuat dan dibayar.</li>
        </ul>

        <h2>Apa yang tidak kami lakukan</h2>
        <ul>
          <li>Kami tidak memproses pembayaran atau pesanan di situs ini.</li>
          <li>Kami tidak pernah meminta password atau kode OTP akun game.</li>
          <li>Kami tidak berafiliasi dengan atau didukung oleh publisher game mana pun.</li>
        </ul>

        <h2>Cara kerjanya</h2>
        <p>
          Situs ini berisi informasi. Saat kamu menekan Top up sekarang, Masuk, atau Daftar, kamu diarahkan ke toko.
          Seluruh transaksi, pembayaran, dan status pesanan ada di sana. Lihat <Link href="/cara-order">cara order</Link>{" "}
          untuk langkah lengkapnya.
        </p>

        <h2>Hubungi kami</h2>
        <p>
          Pertanyaan atau kendala? Buka halaman <Link href="/kontak">Kontak</Link>.
        </p>
      </PageShell>
    </>
  );
}
