import type { Metadata } from "next";
import { site } from "./site";

/**
 * Satu fungsi untuk semua meta halaman, setara blok meta Codwa Studio:
 * title, description, canonical, og:* (termasuk og:image:alt, og:locale, og:locale:alternate),
 * twitter:* (termasuk twitter:image:alt), robots per halaman, dan hreflang (opsional).
 *
 * Pemakaian di setiap page.tsx:
 *   export const metadata = buildMetadata({ title: "Cara Order", description: "...", path: "/cara-order" });
 *
 * Aturan:
 * - og:url = canonical, selalu dari `path`.
 * - twitter:site TIDAK dikeluarkan kecuali site.twitterHandle diisi dengan akun yang benar-benar ada.
 * - hreflang hanya dikeluarkan jika `languages` diberikan (situs ini satu bahasa).
 * - Tanpa gambar OG, twitter:card otomatis menjadi "summary" (bukan "summary_large_image").
 */
type OpenGraph = NonNullable<Metadata["openGraph"]>;

export type SeoImage = { path: string; width?: number; height?: number; alt?: string };

export type SeoInput = {
  title: string;
  description: string;
  path: string; // "/" , "/faq", ...
  absoluteTitle?: boolean; // true: jangan tambahkan " | PEDANG TOP UP"
  ogType?: "website" | "article";
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: SeoImage;
  twitterTitle?: string;
  twitterDescription?: string;
  twitterImage?: SeoImage;
  // khusus ogType "article"
  publishedTime?: string;
  modifiedTime?: string;
  section?: string;
  tags?: string[];
  noindex?: boolean;
  languages?: Record<string, string>; // hreflang, contoh: { "id-ID": "/faq", "en-US": "/en/faq" }
};

const absolute = (path: string) => (/^https?:\/\//.test(path) ? path : `${site.url}${path}`);

const toImage = (image: SeoImage) => ({
  url: absolute(image.path),
  width: image.width,
  height: image.height,
  alt: image.alt ?? site.name,
});

export function buildMetadata(input: SeoInput): Metadata {
  const fullTitle = input.absoluteTitle ? input.title : `${input.title} | ${site.name}`;
  const ogTitle = input.ogTitle ?? fullTitle;
  const ogDescription = input.ogDescription ?? input.description;

  const fallbackImage: SeoImage | undefined = site.ogImage ? { ...site.ogImage, alt: site.name } : undefined;
  const ogImage = input.ogImage ?? fallbackImage;
  const twitterImage = input.twitterImage ?? ogImage;

  const shared = {
    locale: site.locale,
    alternateLocale: site.alternateLocales.length ? site.alternateLocales : undefined,
    siteName: site.name,
    url: input.path,
    title: ogTitle,
    description: ogDescription,
    images: ogImage ? [toImage(ogImage)] : undefined,
  };

  const openGraph: OpenGraph =
    input.ogType === "article"
      ? {
          ...shared,
          type: "article",
          publishedTime: input.publishedTime,
          modifiedTime: input.modifiedTime,
          section: input.section,
          tags: input.tags,
        }
      : { ...shared, type: "website" };

  return {
    title: input.absoluteTitle ? { absolute: input.title } : input.title,
    description: input.description,
    alternates: {
      canonical: input.path,
      ...(input.languages ? { languages: input.languages } : {}),
    },
    ...(input.noindex ? { robots: { index: false, follow: true } } : {}),
    openGraph,
    twitter: {
      card: twitterImage ? "summary_large_image" : "summary",
      title: input.twitterTitle ?? ogTitle,
      description: input.twitterDescription ?? ogDescription,
      images: twitterImage ? [toImage(twitterImage)] : undefined,
      ...(site.twitterHandle ? { site: site.twitterHandle } : {}),
    },
  };
}
