/**
 * Sumber tunggal fakta brand. Isi HANYA dengan data yang benar.
 * Nilai kosong otomatis tidak dikeluarkan di schema (lihat schema.ts).
 */
const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000").replace(/\/$/, "");

export const site = {
  name: "PEDANG TOP UP",
  alternateNames: ["Pedang Topup", "PedangTopup"],
  url: siteUrl,
  language: "id",
  locale: "id_ID",
  alternateLocales: [] as string[], // isi (mis. ["en_US"]) HANYA jika ada versi bahasa lain
  twitterHandle: null as string | null, // contoh "@pedangtopup", HANYA jika akun X benar-benar ada
  homeTitle: "PEDANG TOP UP | Top Up Game Mobile Legends, PUBG, Fortnite & Minecraft",
  description:
    "PEDANG TOP UP: top up game Mobile Legends, PUBG Mobile, Fortnite, dan Minecraft. Lihat cara order, FAQ, dan lanjutkan pesanan lewat toko kami.",
  games: ["Mobile Legends", "PUBG Mobile", "Fortnite", "Minecraft"],

  // Semua field di bawah opsional. Isi HANYA jika benar; yang null tidak dikeluarkan di schema.
  legalName: null as string | null, // nama badan usaha, jika sudah ada
  slogan: null as string | null,
  logo: null as { path: string; width: number; height: number } | null, // contoh: { path: "/logo.webp", width: 600, height: 120 }
  ogImage: null as { path: string; width: number; height: number } | null, // contoh: { path: "/og.png", width: 1200, height: 630 }
  email: null as string | null,
  telephone: null as string | null, // format internasional, contoh: "+62-8xx-xxxx-xxxx"
  whatsapp: null as string | null, // hanya angka, format internasional tanpa +, contoh: "628123456789"
  sameAs: [] as string[], // profil sosial ASLI dengan nama yang sama

  nav: [
    { label: "Cara order", href: "/cara-order" },
    { label: "FAQ", href: "/faq" },
    { label: "Tentang kami", href: "/tentang-kami" },
    { label: "Kontak", href: "/kontak" },
  ],

  moneysite: {
    base: process.env.NEXT_PUBLIC_MONEYSITE_URL ?? "",
    login: process.env.NEXT_PUBLIC_MONEYSITE_LOGIN_URL ?? "",
    register: process.env.NEXT_PUBLIC_MONEYSITE_REGISTER_URL ?? "",
  },
};

/** Link ke moneysite + UTM. Jangan hard-code URL moneysite di komponen. */
export function moneysiteLink(kind: "base" | "login" | "register", placement: string): string {
  const raw = site.moneysite[kind] || site.moneysite.base;
  if (!raw) return "#";
  try {
    const url = new URL(raw);
    url.searchParams.set("utm_source", "pedangtopup");
    url.searchParams.set("utm_medium", "site");
    url.searchParams.set("utm_campaign", placement);
    return url.toString();
  } catch {
    return "#";
  }
}
